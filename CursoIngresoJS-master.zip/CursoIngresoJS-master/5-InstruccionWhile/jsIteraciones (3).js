function mostrar()
{

var clave;
var cont = 0;
var resp;

/*
while (clave != "utn750"){

  var clave = prompt("ingrese la clave.");
  cont ++;
  if (cont >3){
    break;
  }
}

  alert ("Clave correcta.");
*/

/*
do {

  clave = prompt ("Ingrese la clave");
  cont ++;

  if (cont>2){
    break;
    resp = false;
  }

}while (clave != "utn750");

if (resp == false){

  alert ("Clave incorrecta!");

} else {

  alert ("Clave correcta.");

}
*/



}//FIN DE LA FUNCIÓN
