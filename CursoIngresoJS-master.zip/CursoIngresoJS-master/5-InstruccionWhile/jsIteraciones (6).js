function mostrar()
{

  var contador=0;
  var num;
  var acumulador=0;


while (contador <5) {

  num = prompt ("Ingrese numero ", "numero");
  num = parseInt (num);
  acumulador = acumulador + num;
  acumulador = parseInt (acumulador);
  contador ++;
}


document.getElementById('suma').value=acumulador;
document.getElementById('promedio').value=acumulador/5;

}//FIN DE LA FUNCIÓN
