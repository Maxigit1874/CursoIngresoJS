function mostrar()

{
  alert('iteración while');
/*
  var num;
  num = 0;

  while (num < 10 ){

      num ++;

      console.log (num);

  }
*/

/*  CON DO WHILE
var num = 0;

do {

  num ++;
  console.log(num);

}while (num <10);
*/

// CON FOR
var num;

for (num = 1 ; num < 11 ; num ++ ){

  console.log (num);
}

}//FIN DE LA FUNCIÓN
