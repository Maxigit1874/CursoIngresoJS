function mostrar()
{
  alert('iteración while');
/*
  var num;
  num = 11;

  while (num >1){

    num --;
    console.log (num);

  }
*/

/* CON DO WHILE

var num = 11;

do {

  num --;
  console.log (num);

} while (num >1);

*/

// CON FOR

var num;

for (num = 10 ; num > 0 ; num --){

  console.log(num);
}

}//FIN DE LA FUNCIÓN
