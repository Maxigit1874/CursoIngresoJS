function mostrar()
{

  var acumulador=0;
  var contador=0;
  var num;
  var resp;
	var respuesta='si';

  while (respuesta == "si"){

    num = prompt("Ingrese numero ", "numero");
    num = parseInt (num);
    acumulador = acumulador + num;
    contador ++;

    resp = confirm ("Desea continuar?");
      if (resp == true){
        respuesta = "si";
      }else respuesta = "no";


  }

document.getElementById('suma').value=acumulador;
document.getElementById('promedio').value=acumulador/contador;

}//FIN DE LA FUNCIÓN
