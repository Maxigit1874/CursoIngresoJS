function mostrar()
{

  var contador=0;
  var num;
	var positivo=0;
	var negativo=1;
	var resp;
	var respuesta='si';

  while (respuesta == "si"){

    num = prompt ("Ingrese un numero","numero");
    num = parseInt(num);

    if (num >0){
      positivo = positivo + num;
    }else negativo = negativo * num;

    resp = confirm ("Desea continuar?");
    if (resp == true){
      respuesta = "si";
    }else respuesta = "no";
  }

document.getElementById('suma').value=positivo;
document.getElementById('producto').value=negativo;

}//FIN DE LA FUNCIÓN
