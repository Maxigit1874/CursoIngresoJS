function mostrar()
{
	//Genero el número RANDOM entre 1 y 10

	var num;
  //var num2;

  num = Math.floor(Math.random()*(11 - 1)) + 1;

  //num = Math.random()* 10 + 1;
  //num2 = Math.floor(num);

  //= num = Math.floor(Math.random()*11);

	alert(num);
  //alert(num2);

}//FIN DE LA FUNCIÓN
