function mostrar()
{
//tomo la edad  

var edad;
var estadocivil;

edad = document.getElementById("edad").value;
estadocivil = document.getElementById("estadoCivil").value;

//alert(estadocivil);

if ( edad <18 && estadocivil != "Soltero"){

    alert ("Es muy pequeño para NO ser soltero.");

}	


}//FIN DE LA FUNCIÓN