function mostrar()
{

    var planeta;

    planeta = prompt ("Ingrese un planeta del sistema solar.", "planeta");

    switch (planeta){

        case "mercurio":
            
        case "venus":
            alert ("Aca hace mas calor.");
            break;    

        case "tierra":
            alert ("Aca vivimos.");
            break;

        case "marte":
            
        case "jupiter":
            
        case "saturno":

        case "urano":
            alert ("aca hace mas frio.");
            break;
    }

}
